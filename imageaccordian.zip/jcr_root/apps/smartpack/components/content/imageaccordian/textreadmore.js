use(function () {

    var resourceTitle = (this.value1 == null ? '' : this.value1);
	var readLess = resourceTitle.substring(0, 50);
    var readMore = resourceTitle.substring(51);

    return {

        readLess: readLess,
        readMore: readMore,
       

    };
});