function resize() {
    var scr_heights = $(window).height();
    var slider_heights = (15 / 100) * scr_heights;
    var nav_heights = (12 / 100) * scr_heights;
    document.getElementById("header-secton").style.minHeight = slider_heights + "px";
    document.getElementById("navigation-section").style.minHeight = nav_heights + "px";
    document.getElementById("main-content").style.minHeight = scr_heights + "px";

}

resize();
window.onresize = function () {
    resize();
};


function show(x){
    $('#less'+x).show();
    $('#slid'+x).show();
    $('#more'+x).hide();
}
function less(x){
    $('#more'+x).show();
    $('#slid'+x).hide();
    $('#less'+x).hide();
}
$(function() {
    $('.slickSlider').slick({
        dots: true,
        fade: true
    });

    $('.slickSlider').show();
});