package com.aem.capstone.core;


import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.jcr.Node; 
import javax.jcr.LoginException;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.jcr.api.SlingRepository;
import org.apache.jackrabbit.api.security.user.*;

import java.security.Principal;

@Component(immediate = true)
public class UserImporter {
	private static final Logger LOGGER = LoggerFactory.getLogger(UserImporter.class);
	 @Reference
     private SlingRepository repository;
	 
	 public String[] arrayOfURL; 
	
	 
	 protected void activate(ComponentContext componentContext)throws IOException{
         try {
			String[] userArray = this.returnUsers();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
	 
	public String[] returnUsers()throws IOException, InterruptedException{
		
		 
		/*Parse user email id from the database*/
		this.createUsers();
		Thread.sleep(3000);
		this.createProfiles();
		return arrayOfURL;
}
	public void createUsers() throws IOException{
		 	LOGGER.info("inside create users");
		  	try{
	        int userCount = 0;
	        Session session =repository.loginAdministrative(repository.getDefaultWorkspace());//update this to get session with appropraite access
	        UserManager uMgr = ((org.apache.jackrabbit.api.JackrabbitSession)session).getUserManager();
	        //get the group to add user
	        Group author = (Group)uMgr.getAuthorizable("author");
	       
	        
	        while (userCount < arrayOfURL.length) {
	            String userId;
	            userId = arrayOfURL[userCount];
	            User user;
	            //create user
	            // add the newly create to the user
	            author.addMember(uMgr.getAuthorizable(userId));
	            
	            userCount++;
	            LOGGER.info("created "+userId);
	          session.save();
	        }
	        session.save();
	        
		  	}catch(RepositoryException e){
		  		LOGGER.error("exception during cleanup", e);
		  	}
		  	catch(Exception e){
		  		LOGGER.error("exception during cleanup", e);
		  	}
	}
	
	public void createProfiles(){
		 try {
			 LOGGER.info("inside create Profile");
			Session session=repository.loginAdministrative(repository.getDefaultWorkspace());;//get user session
			Node node = session.getNode("/home/users/capstone");
			NodeIterator nodeItr = node.getNodes();
			Node userNode;
			int i=0;
			while(nodeItr.hasNext()){
				
				userNode = nodeItr.nextNode();
				LOGGER.info("node name "+userNode.getName());
				Node profile = userNode.addNode("profile", "nt:unstructured");
				session.save();
				profile.addMixin("rep:AccessControllable");
				profile.setProperty("sling:resourceType", "cq/security/components/profile");
				/*
				 * update user profile data
				 */
				session.save();
				
			}
		} catch (LoginException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			LOGGER.error("exception during cleanup", e);
		}
	}
}