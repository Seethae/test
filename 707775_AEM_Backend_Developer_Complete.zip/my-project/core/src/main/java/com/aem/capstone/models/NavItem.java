package com.aem.capstone.models;

public class NavItem {

	private String url;
	private String label;
	private boolean isActive;
	private String openin;
	
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	public String getOpenin() {
		return openin;
	}
	public void setOpenin(String openin) {
		this.openin = openin;
	}
	
	
}
