package com.aem.capstone.core;

public class HeroBannerItemBean {
	
	private String title = new String();
	private String photoURL = new String();
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getPhotoURL() {
		return photoURL;
	}
	public void setPhotoURL(String photoURL) {
		this.photoURL = photoURL;
	}

}
