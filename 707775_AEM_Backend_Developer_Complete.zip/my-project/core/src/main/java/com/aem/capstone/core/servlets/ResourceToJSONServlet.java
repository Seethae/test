package com.aem.capstone.core.servlets;

import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.PropertyIterator;
import javax.jcr.RepositoryException;
import javax.servlet.ServletException;
import java.io.IOException;
import java.util.Iterator;

/**
 * Skeleton servlet which easily converts a Node as JSON to the PrintWriter.
 */
@SlingServlet(paths = { "/bin/foo" })
public class ResourceToJSONServlet extends SlingSafeMethodsServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The logger */
	private static final Logger logger = LoggerFactory
			.getLogger(ResourceToJSONServlet.class);

	@Override
	protected void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {

		response.setCharacterEncoding("UTF-8");
		response.setContentType("application/json");
		final ResourceResolver resolver = request.getResourceResolver();
		String parentPagePath="/content/we-retail/language-masters/en/experience";
		Resource resource = resolver
				.getResource(parentPagePath);
		Node node;
		PageManager pageManager = null;
		Page page = null;

		try {
			pageManager = resolver.adaptTo(PageManager.class);
			page = pageManager.getContainingPage(resource);
			Iterator<Page> pageItr = page.listChildren();
			Page childPage;
			JSONObject json = new JSONObject();
			JSONObject jsonObj;
			String pageTitle = new String();
			while (pageItr.hasNext()) {
				jsonObj = new JSONObject();
				childPage = pageItr.next();
				logger.info(childPage.getPath());
				jsonObj.put("path", childPage.getPath());
				pageTitle = childPage.getTitle();
				resource = resolver.getResource(childPage.getPath()
						+ "/jcr:content/root/hero_image");
				if (null == resource)
					continue;
				else
					node = resource.adaptTo(Node.class);
/*update the below properties based on the page template of Neat being used*/
				PropertyIterator pitr = node.getProperties();
				while (pitr.hasNext()) {
					Property p = pitr.nextProperty();
					if (p.getName().equalsIgnoreCase("fileReference")) {
						jsonObj.put("fileReference", p.getString());
					} else if (p.getName().equalsIgnoreCase("heading")) {
						jsonObj.put("heading", p.getString());
					} else if (p.getName().equalsIgnoreCase("title")) {
						jsonObj.put("title", p.getString());
					}
				}
				json.put(pageTitle, jsonObj);
			}
			response.getWriter().print(json.toString());
			response.setStatus(SlingHttpServletResponse.SC_OK);

		} catch (RepositoryException rpe) {
			rpe.printStackTrace();
		} catch (JSONException e) {

			e.printStackTrace();

		}

	}
}
