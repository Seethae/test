package com.aem.capstone.models;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Named;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Required;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

@Model(
        // (Almost) always adapt from the SlingHttpServetlRequest object; Adapting from multiple classes is supported,
        // however often results in unsatisfied injections and complex logic in the @PostConstruct to derive the required
        // field values.
        adaptables = SlingHttpServletRequest.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class Footer {
	private static final Logger LOGGER = LoggerFactory.getLogger(Footer.class);

    @Self
    private SlingHttpServletRequest request;

    @Self @Via("resource")
    private Resource resource;

    // ALWAYS try to use explicit injectors (ie. @ValueMapValue vs the ambiguous @Inject).
    // This reduces confusion of how values are being injected.

    // Inject a property name whose name does NOT match the Model field name
    // Since the Default inject strategy is OPTIONAL (set on the @Model), we can mark injections as @Required. @Optional can be used if the default strategy is REQUIRED.
    @ValueMapValue
    @Named("heading")
    @Required
    private String heading;
    
    
    @ValueMapValue
    @Named("copyrights")
    @Required
    private String copyrights;
  
    // Injection will occur over all Injectors based on Ranking;
    // Force an Injector using @Source(..)
    // If an Injector is not working; ensure you are using the latest version of Sling Models
    @SlingObject
    private ResourceResolver resourceResolver;

    // Internal state populated via @PostConstruct logic
    private Page page;
    private List<NavItem> linkItems;

	@PostConstruct
    // PostConstructs are called after all the injection has occurred, but before the Model object is returned for use.
    private void init() {
        // Note that @PostConstruct code will always be executed on Model instantiation.
        // If the work done in PostConstruct is expensive and not always used in the consumption of the model, it is
        // better to lazy-execute the logic in the getter and persist the result in  model state if it is requested again.
        page = resourceResolver.adaptTo(PageManager.class).getContainingPage(resource);
        LOGGER.info(" page path {} ", getPath());
        
        
    }

   	
 	public List<NavItem> getLinkItems() {
		return linkItems;
	}



	/**
     * @return the resource path to this content. Does not include the extension.
     */
    public String getPath() {
        return page.getPath();
    }


	public String getHeading() {
		return heading;
	}


	public String getCopyrights() {
		return copyrights;
	}
}
