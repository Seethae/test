package com.aem.capstone.models;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageFilter;
import com.day.cq.wcm.api.PageManager;

@Model(adaptables = {  Resource.class, SlingHttpServletRequest.class })
public class Header {

	private static final Logger LOGGER = LoggerFactory.getLogger(Header.class);
	private List<NavItem> linkItems;

	public List<NavItem> getLinkItems() {
		return linkItems;
	}

	@Inject @Optional
	private String rootpath;

	@Inject
	private PageManager pageManager;

	@Inject
	private Page currentPage;

	String PN_ROOT_PATH = "rootPath";

	
	@PostConstruct
	protected void init() {
		linkItems = new ArrayList<NavItem>();
		LOGGER.info(" rootpath {} ", rootpath);
		Page rootPage = pageManager.getPage(rootpath);
		if(rootPage!= null) {
			String currentNavPath = currentPage.getAbsoluteParent(2).getPath();
			LOGGER.info("currentNavPath  {} ", currentNavPath);
			Iterator<Page> childPages = rootPage.listChildren(new PageFilter());
			while (childPages.hasNext()) {
				Page childPage = childPages.next();
				String path = childPage.getPath();
				NavItem item = new NavItem();
				item.setUrl(path);
				if (path.equalsIgnoreCase(currentNavPath)) {
					item.setActive(true);
				} else {
					item.setActive(false);
				}
				item.setLabel(childPage.getTitle());
				item.setOpenin(childPage.getTitle());
				linkItems.add(item);
			}
		}
		

	}

}
