"use strict";
use(function() {
    var pagetype=pageManager.getPage(this.pagepath);
    var pageTitle;
    if(pagetype != null){
		pageTitle= pagetype.getTitle();
    }
    return pageTitle;
    });