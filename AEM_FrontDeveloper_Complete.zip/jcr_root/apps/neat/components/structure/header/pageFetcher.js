"use strict";
use(function() {
    var parentPage=currentPage.getAbsoluteParent(2);
    return parentPage;
    });