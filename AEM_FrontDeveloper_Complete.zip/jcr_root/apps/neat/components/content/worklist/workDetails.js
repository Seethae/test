"use strict";
use(function() {
    var workPage=this.pageType;
    var currentCount=this.listCount;
    var limit =(currentCount<=properties.numList);
    var resource=null;
    var valuemap=null;
    if(workPage.hasContent()){
       resource =workPage.getContentResource("imageBannerNode");
        if(null!=resource){
       		valuemap= resource.adaptTo(Packages.org.apache.sling.api.resource.ValueMap);
        }
    }
    return{
        valuemap:valuemap,
        limit: limit
    };
});