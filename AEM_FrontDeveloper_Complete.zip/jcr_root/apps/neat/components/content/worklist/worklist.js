"use strict";
use(function() {
    var pagetype=pageManager.getPage(this.pagepath);
    var pageChildren;
    var workDetailPage;
    if(pagetype != null){
		pageChildren= pagetype.listChildren();
    }
    return pageChildren;
    });